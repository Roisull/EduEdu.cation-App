package com.example.eduedu.admin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.eduedu.R

class AddUserActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_user)
    }
}