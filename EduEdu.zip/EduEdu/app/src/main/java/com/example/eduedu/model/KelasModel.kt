package com.example.eduedu.model

import android.graphics.Bitmap

class KelasModel(var kelasId: Int, var title: String, var price: Int, var deskripsi: String, var image: Bitmap)