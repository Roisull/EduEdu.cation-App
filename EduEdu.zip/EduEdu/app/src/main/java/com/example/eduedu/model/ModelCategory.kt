package com.example.eduedu.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
class ModelCategory (
    var category: String? = null
):Parcelable