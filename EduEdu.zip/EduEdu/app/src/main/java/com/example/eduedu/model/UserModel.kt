package com.example.eduedu.model

class UserModel(var email: String, var nama: String, var no_hp: String, var password: String)