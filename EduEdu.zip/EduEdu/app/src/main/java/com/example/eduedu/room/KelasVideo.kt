//package com.example.eduedu.room
//
//import android.graphics.Bitmap
//import androidx.room.Entity
//import androidx.room.PrimaryKey
//import java.sql.Blob
//
//
//@Entity
//data class KelasVideo(
//
//    @PrimaryKey(autoGenerate = true)
//    val id: Int,
//    val title: String,
//    val price: Int,
//    val thumbnail: Bitmap
//)
//
